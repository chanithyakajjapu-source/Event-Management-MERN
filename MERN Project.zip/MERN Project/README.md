# 🚀 Full-Stack MERN Personal Portfolio Website

A modern, production-grade **Personal Portfolio Web Application** engineered using the **MERN Stack** (MongoDB, Express.js, React, Node.js) with Tailwind CSS, Lucide Icons, and an integrated Admin Content Management System (CMS).

![Portfolio Preview](https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1200&q=80)

---

## 🌟 Key Highlights

- **⚡ Modern Frontend**: React 18 + Vite with Tailwind CSS, glassmorphism, responsive navigation, and smooth scroll behavior.
- **🛡️ Secure Backend API**: Express.js RESTful API architecture with JWT authentication and bcrypt password hashing.
- **🗄️ Database Flexibility (MongoDB + In-Memory Fallback)**:
  - Connects to local MongoDB or MongoDB Atlas via Mongoose.
  - **Zero-Setup In-Memory Fallback**: Runs instantly out-of-the-box even if MongoDB is not running on your machine yet!
- **📬 Functional Contact Form**: Direct API submission (`POST /api/contact`) that saves visitor inquiries into MongoDB and notifies the admin.
- **🔐 Integrated Admin CMS**:
  - Secure login portal (`admin@example.com` / `admin123`).
  - **Inquiries Inbox**: View messages submitted by visitors, mark as read, delete, and quick reply via email.
  - **Project Manager**: Add, edit, and delete portfolio projects dynamically without touching code!
- **📱 Fully Responsive**: Pixel-perfect layout across mobile, tablet, and widescreen monitors.

---

## 🛠️ Tech Stack

| Layer | Technologies |
|---|---|
| **Frontend** | React 18, Vite, Tailwind CSS, Lucide Icons, Axios |
| **Backend** | Node.js (v18+ or v20+), Express.js, CORS, Dotenv |
| **Database** | MongoDB, Mongoose ORM (with in-memory fallback store) |
| **Authentication** | JSON Web Tokens (JWT), Bcrypt.js |

---

## 📁 Project Architecture

```
MERN project/
├── backend/
│   ├── src/
│   │   ├── config/
│   │   │   └── db.js               # MongoDB connection & fallback handler
│   │   ├── controllers/
│   │   │   ├── authController.js    # Admin login & JWT generation
│   │   │   ├── contactController.js # Contact inquiries CRUD
│   │   │   ├── projectController.js # Portfolio projects CRUD
│   │   │   ├── skillController.js   # Skills data provider
│   │   │   └── profileController.js # Bio, experiences, stats
│   │   ├── data/
│   │   │   ├── initialData.js       # Default seed dataset
│   │   │   └── memoryStore.js       # Fallback store (zero-config)
│   │   ├── middleware/
│   │   │   ├── authMiddleware.js    # JWT protection middleware
│   │   │   └── errorMiddleware.js   # 404 & global error handler
│   │   ├── models/
│   │   │   ├── Contact.js           # Mongoose contact schema
│   │   │   ├── Experience.js        # Mongoose experience schema
│   │   │   ├── Project.js           # Mongoose project schema
│   │   │   ├── Skill.js             # Mongoose skill schema
│   │   │   └── User.js              # Admin user schema with bcrypt
│   │   ├── routes/
│   │   │   ├── authRoutes.js        # /api/auth
│   │   │   ├── contactRoutes.js     # /api/contact
│   │   │   ├── profileRoutes.js     # /api/profile
│   │   │   ├── projectRoutes.js     # /api/projects
│   │   │   └── skillRoutes.js       # /api/skills
│   │   ├── seeder.js                # One-click database seeding script
│   │   └── server.js                # Express app entry point
│   ├── .env                         # Server environment variables
│   ├── .env.example
│   └── package.json
│
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Admin/
│   │   │   │   ├── AdminDashboard.jsx # CMS Tabs: Inquiries & Projects
│   │   │   │   ├── AdminModal.jsx     # Login modal & CMS router
│   │   │   │   ├── MessagesList.jsx   # Inquiries reader & actions
│   │   │   │   └── ProjectEditor.jsx  # Add/Edit project form
│   │   │   ├── About.jsx              # Bio & core engineering pillars
│   │   │   ├── Contact.jsx            # Live interactive contact form
│   │   │   ├── Experience.jsx         # Career milestones timeline
│   │   │   ├── Footer.jsx             # Footer & copyright
│   │   │   ├── Hero.jsx               # Hero banner with code graphic
│   │   │   ├── Navbar.jsx             # Nav links & Admin portal button
│   │   │   ├── ProjectModal.jsx       # Case study details modal
│   │   │   ├── Projects.jsx           # Filterable projects grid
│   │   │   ├── Skills.jsx             # Categorized skills & progress
│   │   │   └── Testimonials.jsx       # Colleague & client endorsements
│   │   ├── context/
│   │   │   └── AuthContext.jsx        # JWT state management
│   │   ├── data/
│   │   │   └── defaultPortfolioData.js# Client offline fallback data
│   │   ├── services/
│   │   │   └── api.js                 # Axios API client
│   │   ├── App.jsx                    # Root application component
│   │   ├── index.css                  # Tailwind CSS & custom styles
│   │   └── main.jsx                   # React DOM root
│   ├── index.html
│   ├── package.json
│   ├── tailwind.config.js
│   └── vite.config.js                 # Vite configuration with /api proxy
│
├── package.json                       # Root workspace orchestrator
└── README.md
```

---

## ⚡ Quick Start Guide

### 1. Install Dependencies

You can install dependencies for both the backend and frontend with a single command:

```bash
# Option A: From the root folder
npm run install-all

# Option B: Or install individually
cd backend && npm install
cd ../frontend && npm install
```

### 2. Configure Environment Variables

The backend already contains a default `.env` file pre-configured for local development.

```env
PORT=5000
NODE_ENV=development
MONGODB_URI=mongodb://127.0.0.1:27017/portfolio_db
JWT_SECRET=portfolio_jwt_secret_dev_key_secure_987654321
ADMIN_EMAIL=admin@example.com
ADMIN_PASSWORD=admin123
```

> **Note**: If you want to use MongoDB Atlas (Cloud), paste your MongoDB connection string in `backend/.env`. If you don't have MongoDB running right now, **don't worry!** The backend automatically starts in memory mode so you can immediately see and use the entire app!

### 3. Start the Backend API

In terminal 1:
```bash
cd backend
npm run dev
```
The backend server will start on `http://localhost:5000`.

### 4. Start the Frontend Application

In terminal 2:
```bash
cd frontend
npm run dev
```
Open your browser and navigate to **`http://localhost:5173`**.

---

## 🔐 Admin Portal & CMS

Click the **Admin Portal** button on the top right of the navigation bar to sign in:

- **Email**: `admin@example.com`
- **Password**: `admin123`

### What You Can Do in the Admin Portal:
1. **Manage Contact Messages**:
   - View inquiries submitted via the live contact form.
   - Mark messages as read.
   - Reply directly to visitors via email.
   - Delete inquiries.
2. **Manage Projects**:
   - Add new projects with custom title, category, description, live link, GitHub link, image, and tech tags.
   - Edit existing projects.
   - Delete projects.

---

## 📡 REST API Reference

| Method | Endpoint | Access | Description |
|---|---|---|---|
| `GET` | `/api/health` | Public | Backend health & database status |
| `GET` | `/api/projects` | Public | List all portfolio projects |
| `GET` | `/api/projects/:id` | Public | Get single project details |
| `POST` | `/api/projects` | Private (Admin) | Create a new project |
| `PUT` | `/api/projects/:id` | Private (Admin) | Update an existing project |
| `DELETE`| `/api/projects/:id` | Private (Admin) | Delete a project |
| `GET` | `/api/skills` | Public | List technical skills |
| `GET` | `/api/profile` | Public | Get profile bio, experience, stats |
| `POST` | `/api/contact` | Public | Submit visitor contact message |
| `GET` | `/api/contact` | Private (Admin) | Retrieve all contact inquiries |
| `PATCH`| `/api/contact/:id/read` | Private (Admin) | Mark contact message as read |
| `DELETE`| `/api/contact/:id` | Private (Admin) | Delete contact inquiry |
| `POST` | `/api/auth/login` | Public | Admin authentication |
| `GET` | `/api/auth/me` | Private (Admin) | Current authenticated user |

---

## 🌱 Seeding MongoDB Database (Optional)

When you have MongoDB running locally or on MongoDB Atlas, you can seed it with ready-made developer portfolio data:

```bash
cd backend
npm run seed
```

To wipe the database:
```bash
npm run seed -d
```

---

## 🎨 Customizing Your Portfolio

1. **Your Name & Bio**: Update `backend/src/data/initialData.js` and `frontend/src/data/defaultPortfolioData.js` with your personal information, links, and avatar.
2. **Projects**: Add your own GitHub repositories, live demo links, and descriptions either in `initialData.js` or directly via the **Admin Portal** UI.
3. **Skills**: Customize your tech stack categories in `initialData.js`.
4. **Theme Colors**: Modify `frontend/tailwind.config.js` to change primary accent colors.

---

## 🚀 Deployment Guide

### Deploy Frontend (Vercel / Netlify):
1. Build the frontend: `cd frontend && npm run build`.
2. Connect your repository to Vercel/Netlify. Set root directory to `frontend` and build command to `npm run build`.

### Deploy Backend (Render / Railway):
1. Connect repository to Render/Railway. Set root directory to `backend`.
2. Add environment variables from `backend/.env` (including your MongoDB Atlas URI).
3. Set start command to `node src/server.js`.

---

© 2026 Alex Morgan. Built with the MERN Stack.

