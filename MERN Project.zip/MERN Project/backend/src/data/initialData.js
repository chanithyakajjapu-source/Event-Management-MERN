export const initialProfile = {
  name: "Alex Morgan",
  title: "Full Stack MERN Developer",
  tagline: "Building high-performance web applications, scalable backends, and pixel-perfect interactive user interfaces.",
  bio: "Hello! I am a passionate Full Stack Software Engineer specializing in the MERN stack (MongoDB, Express, React, Node.js). I love designing elegant architectures, crafting intuitive UI/UX, and engineering reliable REST APIs. When I'm not writing code, I actively contribute to open source and mentor aspiring developers.",
  location: "San Francisco, CA / Remote",
  email: "alex.morgan.dev@example.com",
  phone: "+1 (555) 019-2834",
  github: "https://github.com",
  linkedin: "https://linkedin.com",
  twitter: "https://twitter.com",
  resumeUrl: "/resume-sample.pdf",
  stats: [
    { label: "Years Experience", value: "3+" },
    { label: "Completed Projects", value: "24+" },
    { label: "Open Source Stars", value: "1.2k" },
    { label: "Client Satisfaction", value: "100%" }
  ]
};

export const initialProjects = [
  {
    title: "DevFlow - Agile Collaboration Platform",
    description: "A real-time project management and team collaboration dashboard featuring kanban boards, live chat, role-based access control, and automated activity logs.",
    category: "Full Stack",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80",
    tags: ["React", "Node.js", "Express", "MongoDB", "Socket.io", "Tailwind CSS"],
    liveUrl: "https://example.com/devflow",
    githubUrl: "https://github.com/example/devflow",
    featured: true,
    highlights: [
      "Real-time websocket events for instant collaboration",
      "JWT authentication with refresh tokens",
      "MongoDB aggregation pipelines for team analytics"
    ],
    order: 1
  },
  {
    title: "EcoMart - E-Commerce Platform",
    description: "Full-featured online store with product filtering, cart state management, Stripe payment processing, customer reviews, and order tracking.",
    category: "Full Stack",
    image: "https://images.unsplash.com/photo-1472851294608-062f824d29cc?auto=format&fit=crop&w=800&q=80",
    tags: ["React", "Redux Toolkit", "Express", "MongoDB", "Stripe API", "Tailwind CSS"],
    liveUrl: "https://example.com/ecomart",
    githubUrl: "https://github.com/example/ecomart",
    featured: true,
    highlights: [
      "Seamless Stripe Checkout integration",
      "Admin portal for product and inventory management",
      "Optimized image uploads with Cloudinary"
    ],
    order: 2
  },
  {
    title: "PulseAI - Content Intelligence Suite",
    description: "AI-assisted writing assistant with prompt history, custom tone analyzers, markdown export, and token usage dashboards powered by LLM APIs.",
    category: "Frontend",
    image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80",
    tags: ["React", "Vite", "Tailwind CSS", "REST API", "Framer Motion"],
    liveUrl: "https://example.com/pulseai",
    githubUrl: "https://github.com/example/pulseai",
    featured: true,
    highlights: [
      "Ultra-responsive dark mode UI with glassmorphism",
      "Streaming API response rendering",
      "Local storage sync for drafts"
    ],
    order: 3
  },
  {
    title: "CloudVault - Secure API Gateway & Storage",
    description: "Microservice-ready RESTful API backend handling encrypted file storage, rate limiting, audit logs, and OAuth2 social authentication.",
    category: "Backend",
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80",
    tags: ["Node.js", "Express", "MongoDB", "JWT", "Redis", "Docker"],
    liveUrl: "https://example.com/cloudvault-api",
    githubUrl: "https://github.com/example/cloudvault-api",
    featured: false,
    highlights: [
      "Standardized error handling and request sanitization",
      "Rate limiting with Redis token bucket",
      "Comprehensive Postman test collection"
    ],
    order: 4
  },
  {
    title: "CryptoScope - Realtime Market Tracker",
    description: "Interactive cryptocurrency analytics app displaying live price charts, order books, historical performance graphs, and personalized watchlist alerts.",
    category: "Frontend",
    image: "https://images.unsplash.com/photo-1621416894569-0f39ed31d247?auto=format&fit=crop&w=800&q=80",
    tags: ["React", "Chart.js", "Tailwind CSS", "CoinGecko API"],
    liveUrl: "https://example.com/cryptoscope",
    githubUrl: "https://github.com/example/cryptoscope",
    featured: false,
    highlights: [
      "Dynamic interactive charting with time-range toggles",
      "Clean currency conversion calculations",
      "Mobile-first responsive design"
    ],
    order: 5
  },
  {
    title: "TaskPilot - Lightweight CLI & Webhook Manager",
    description: "Developer utility to orchestrate asynchronous tasks, monitor webhook deliveries, and retry failed HTTP requests automatically.",
    category: "Backend",
    image: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80",
    tags: ["Node.js", "Express", "MongoDB", "Worker Threads"],
    liveUrl: "https://example.com/taskpilot",
    githubUrl: "https://github.com/example/taskpilot",
    featured: false,
    highlights: [
      "Exponential backoff retry policy",
      "Webhook signature validation (HMAC SHA-256)",
      "Lightweight embedded web dashboard"
    ],
    order: 6
  }
];

export const initialSkills = [
  // Frontend
  { name: "React.js", category: "Frontend", proficiency: 95, icon: "react" },
  { name: "JavaScript (ES6+)", category: "Frontend", proficiency: 95, icon: "javascript" },
  { name: "TypeScript", category: "Frontend", proficiency: 85, icon: "typescript" },
  { name: "Next.js", category: "Frontend", proficiency: 80, icon: "nextjs" },
  { name: "Tailwind CSS", category: "Frontend", proficiency: 92, icon: "tailwind" },
  { name: "HTML5 / CSS3", category: "Frontend", proficiency: 95, icon: "html" },
  { name: "Redux / Zustand", category: "Frontend", proficiency: 85, icon: "redux" },

  // Backend
  { name: "Node.js", category: "Backend", proficiency: 90, icon: "nodejs" },
  { name: "Express.js", category: "Backend", proficiency: 92, icon: "express" },
  { name: "RESTful APIs", category: "Backend", proficiency: 95, icon: "api" },
  { name: "GraphQL", category: "Backend", proficiency: 75, icon: "graphql" },
  { name: "JWT & OAuth2", category: "Backend", proficiency: 88, icon: "security" },
  { name: "Socket.io", category: "Backend", proficiency: 82, icon: "socket" },

  // Database
  { name: "MongoDB & Mongoose", category: "Database", proficiency: 92, icon: "mongodb" },
  { name: "PostgreSQL", category: "Database", proficiency: 78, icon: "postgresql" },
  { name: "Redis", category: "Database", proficiency: 80, icon: "redis" },

  // DevOps & Tools
  { name: "Git & GitHub", category: "DevOps & Tools", proficiency: 90, icon: "git" },
  { name: "Docker", category: "DevOps & Tools", proficiency: 78, icon: "docker" },
  { name: "Postman / Thunder Client", category: "DevOps & Tools", proficiency: 90, icon: "postman" },
  { name: "Vercel / Render / AWS", category: "DevOps & Tools", proficiency: 82, icon: "cloud" },
  { name: "Vite / Webpack", category: "DevOps & Tools", proficiency: 88, icon: "vite" }
];

export const initialExperiences = [
  {
    role: "Senior Full Stack Engineer",
    company: "Apex Digital Solutions",
    period: "2023 - Present",
    location: "Remote",
    description: "Leading frontend and backend development for client-facing cloud applications. Architected resilient REST APIs with Express and MongoDB, reducing server latency by 35%. Mentored 4 junior engineers.",
    technologies: ["React", "Node.js", "Express", "MongoDB", "Tailwind CSS", "Docker"]
  },
  {
    role: "Full Stack Developer",
    company: "HyperScale Tech",
    period: "2021 - 2023",
    location: "San Francisco, CA",
    description: "Built modular web interfaces in React and robust backend microservices in Node.js. Integrated Stripe payment gateways, automated CI/CD deployment pipelines, and improved test coverage to 85%.",
    technologies: ["JavaScript", "React", "Node.js", "MongoDB", "Redux", "Jest"]
  },
  {
    role: "Frontend Developer Intern",
    company: "CodeCraft Studios",
    period: "2020 - 2021",
    location: "San Francisco, CA",
    description: "Developed responsive landing pages, interactive dashboards, and design system components. Partnered with UX designers to translate Figma mockups into reusable React components.",
    technologies: ["React", "HTML5", "CSS3", "JavaScript", "Git"]
  }
];

export const initialTestimonials = [
  {
    quote: "Alex is an outstanding engineer who consistently delivers high-quality, maintainable code. His expertise in the MERN stack transformed our product delivery timeline.",
    name: "Sarah Jenkins",
    role: "VP of Engineering at CloudSphere",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80"
  },
  {
    quote: "Working with Alex was a fantastic experience. He has a rare combination of frontend polish and backend depth that makes complex features feel simple.",
    name: "David Chen",
    role: "Product Manager at Apex Labs",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80"
  }
];

