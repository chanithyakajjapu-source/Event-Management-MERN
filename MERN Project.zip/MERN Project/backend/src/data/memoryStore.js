import { initialProfile, initialProjects, initialSkills, initialExperiences, initialTestimonials } from './initialData.js';
import crypto from 'crypto';

class MemoryStore {
  constructor() {
    this.profile = { ...initialProfile };
    this.projects = initialProjects.map((p, index) => ({
      _id: `mem_proj_${index + 1}`,
      ...p,
      createdAt: new Date(),
      updatedAt: new Date()
    }));
    this.skills = initialSkills.map((s, index) => ({
      _id: `mem_skill_${index + 1}`,
      ...s
    }));
    this.experiences = initialExperiences.map((e, index) => ({
      _id: `mem_exp_${index + 1}`,
      ...e
    }));
    this.testimonials = initialTestimonials.map((t, index) => ({
      _id: `mem_test_${index + 1}`,
      ...t
    }));
    this.contacts = [
      {
        _id: 'mem_contact_1',
        name: 'Jordan Smith',
        email: 'jordan@example.com',
        subject: 'Exciting Full Stack Opportunity',
        message: 'Hi Alex, I came across your portfolio and was thoroughly impressed by your MERN projects. Would love to discuss an open Senior Engineer role on our team!',
        isRead: false,
        createdAt: new Date(Date.now() - 3600000 * 2)
      }
    ];
    this.users = [];
  }

  // Projects
  getProjects(filter = {}) {
    let result = [...this.projects];
    if (filter.category && filter.category !== 'All') {
      result = result.filter(p => p.category.toLowerCase() === filter.category.toLowerCase());
    }
    if (filter.featured !== undefined) {
      result = result.filter(p => p.featured === filter.featured);
    }
    return result.sort((a, b) => (a.order || 99) - (b.order || 99));
  }

  getProjectById(id) {
    return this.projects.find(p => p._id === id);
  }

  createProject(projectData) {
    const newProject = {
      _id: `mem_proj_${crypto.randomUUID().slice(0, 8)}`,
      ...projectData,
      order: projectData.order || this.projects.length + 1,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.projects.push(newProject);
    return newProject;
  }

  updateProject(id, projectData) {
    const index = this.projects.findIndex(p => p._id === id);
    if (index === -1) return null;
    this.projects[index] = {
      ...this.projects[index],
      ...projectData,
      updatedAt: new Date()
    };
    return this.projects[index];
  }

  deleteProject(id) {
    const index = this.projects.findIndex(p => p._id === id);
    if (index === -1) return false;
    this.projects.splice(index, 1);
    return true;
  }

  // Skills
  getSkills(category) {
    if (category && category !== 'All') {
      return this.skills.filter(s => s.category.toLowerCase() === category.toLowerCase());
    }
    return [...this.skills];
  }

  createSkill(skillData) {
    const newSkill = {
      _id: `mem_skill_${crypto.randomUUID().slice(0, 8)}`,
      ...skillData
    };
    this.skills.push(newSkill);
    return newSkill;
  }

  // Contacts
  getContacts() {
    return [...this.contacts].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  createContact(contactData) {
    const newContact = {
      _id: `mem_contact_${crypto.randomUUID().slice(0, 8)}`,
      ...contactData,
      isRead: false,
      createdAt: new Date()
    };
    this.contacts.unshift(newContact);
    return newContact;
  }

  markContactAsRead(id) {
    const contact = this.contacts.find(c => c._id === id);
    if (!contact) return null;
    contact.isRead = true;
    return contact;
  }

  deleteContact(id) {
    const index = this.contacts.findIndex(c => c._id === id);
    if (index === -1) return false;
    this.contacts.splice(index, 1);
    return true;
  }

  // Profile & Stats
  getProfile() {
    return {
      ...this.profile,
      projectsCount: this.projects.length,
      skillsCount: this.skills.length,
      experiences: this.experiences,
      testimonials: this.testimonials
    };
  }

  updateProfile(data) {
    this.profile = { ...this.profile, ...data };
    return this.profile;
  }
}

export const memoryStore = new MemoryStore();

