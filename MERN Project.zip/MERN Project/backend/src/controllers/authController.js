import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import { isMongoConnected } from '../config/db.js';

const generateToken = (id, name, email) => {
  return jwt.sign(
    { id, name, email },
    process.env.JWT_SECRET || 'dev_secret_key',
    { expiresIn: '30d' }
  );
};

// @desc    Auth admin & get token
// @route   POST /api/auth/login
// @access  Public
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Please provide email and password' });
    }

    const defaultAdminEmail = (process.env.ADMIN_EMAIL || 'admin@example.com').toLowerCase();
    const defaultAdminPassword = process.env.ADMIN_PASSWORD || 'admin123';

    if (isMongoConnected) {
      const user = await User.findOne({ email: email.toLowerCase() }).select('+password');

      if (user && (await user.matchPassword(password))) {
        return res.json({
          success: true,
          data: {
            _id: user._id,
            name: user.name,
            email: user.email,
            role: user.role,
            token: generateToken(user._id, user.name, user.email)
          }
        });
      }

      // Check fallback default admin if no DB user exists yet
      if (email.toLowerCase() === defaultAdminEmail && password === defaultAdminPassword) {
        return res.json({
          success: true,
          data: {
            _id: 'default_admin_id',
            name: 'Portfolio Admin',
            email: defaultAdminEmail,
            role: 'admin',
            token: generateToken('default_admin_id', 'Portfolio Admin', defaultAdminEmail)
          }
        });
      }

      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    } else {
      // Memory Store Auth
      if (email.toLowerCase() === defaultAdminEmail && password === defaultAdminPassword) {
        return res.json({
          success: true,
          data: {
            _id: 'mem_admin_1',
            name: 'Portfolio Admin (Dev)',
            email: defaultAdminEmail,
            role: 'admin',
            token: generateToken('mem_admin_1', 'Portfolio Admin', defaultAdminEmail)
          }
        });
      }

      return res.status(401).json({ success: false, message: 'Invalid credentials. Default: admin@example.com / admin123' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get current user profile
// @route   GET /api/auth/me
// @access  Private
export const getMe = async (req, res) => {
  try {
    res.json({
      success: true,
      data: req.user
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

