import Skill from '../models/Skill.js';
import { isMongoConnected } from '../config/db.js';
import { memoryStore } from '../data/memoryStore.js';

// @desc    Get all skills (optional category filter)
// @route   GET /api/skills
// @access  Public
export const getSkills = async (req, res) => {
  try {
    const { category } = req.query;

    if (isMongoConnected) {
      const query = category && category !== 'All' ? { category } : {};
      const skills = await Skill.find(query).sort({ proficiency: -1 });
      return res.json({ success: true, count: skills.length, data: skills });
    } else {
      const skills = memoryStore.getSkills(category);
      return res.json({ success: true, count: skills.length, data: skills });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Create new skill
// @route   POST /api/skills
// @access  Private (Admin)
export const createSkill = async (req, res) => {
  try {
    const { name, category, proficiency, icon } = req.body;

    if (!name || !category) {
      return res.status(400).json({ success: false, message: 'Name and category are required' });
    }

    const payload = {
      name,
      category,
      proficiency: Number(proficiency) || 80,
      icon: icon || 'code'
    };

    if (isMongoConnected) {
      const skill = await Skill.create(payload);
      return res.status(201).json({ success: true, data: skill });
    } else {
      const skill = memoryStore.createSkill(payload);
      return res.status(201).json({ success: true, data: skill });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

