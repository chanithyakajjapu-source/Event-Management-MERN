import Contact from '../models/Contact.js';
import { isMongoConnected } from '../config/db.js';
import { memoryStore } from '../data/memoryStore.js';

// @desc    Submit a contact inquiry
// @route   POST /api/contact
// @access  Public
export const submitContact = async (req, res) => {
  try {
    const { name, email, subject, message } = req.body;

    if (!name || !email || !message) {
      return res.status(400).json({
        success: false,
        message: 'Please provide name, email, and message content'
      });
    }

    const emailRegex = /^\S+@\S+\.\S+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid email address'
      });
    }

    const contactData = {
      name: name.trim(),
      email: email.trim().toLowerCase(),
      subject: subject ? subject.trim() : 'Portfolio Contact Form',
      message: message.trim()
    };

    if (isMongoConnected) {
      const contact = await Contact.create(contactData);
      return res.status(201).json({
        success: true,
        message: 'Thank you! Your message has been sent successfully.',
        data: contact
      });
    } else {
      const contact = memoryStore.createContact(contactData);
      return res.status(201).json({
        success: true,
        message: 'Thank you! Your message has been received successfully.',
        data: contact
      });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get all contact messages
// @route   GET /api/contact
// @access  Private (Admin)
export const getContacts = async (req, res) => {
  try {
    if (isMongoConnected) {
      const contacts = await Contact.find().sort({ createdAt: -1 });
      return res.json({
        success: true,
        count: contacts.length,
        data: contacts
      });
    } else {
      const contacts = memoryStore.getContacts();
      return res.json({
        success: true,
        count: contacts.length,
        data: contacts
      });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Mark contact message as read
// @route   PATCH /api/contact/:id/read
// @access  Private (Admin)
export const markContactRead = async (req, res) => {
  try {
    const { id } = req.params;

    if (isMongoConnected) {
      const contact = await Contact.findByIdAndUpdate(id, { isRead: true }, { new: true });
      if (!contact) {
        return res.status(404).json({ success: false, message: 'Message not found' });
      }
      return res.json({ success: true, data: contact });
    } else {
      const contact = memoryStore.markContactAsRead(id);
      if (!contact) {
        return res.status(404).json({ success: false, message: 'Message not found' });
      }
      return res.json({ success: true, data: contact });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Delete contact message
// @route   DELETE /api/contact/:id
// @access  Private (Admin)
export const deleteContact = async (req, res) => {
  try {
    const { id } = req.params;

    if (isMongoConnected) {
      const contact = await Contact.findByIdAndDelete(id);
      if (!contact) {
        return res.status(404).json({ success: false, message: 'Message not found' });
      }
      return res.json({ success: true, message: 'Message deleted successfully' });
    } else {
      const deleted = memoryStore.deleteContact(id);
      if (!deleted) {
        return res.status(404).json({ success: false, message: 'Message not found' });
      }
      return res.json({ success: true, message: 'Message deleted successfully' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

