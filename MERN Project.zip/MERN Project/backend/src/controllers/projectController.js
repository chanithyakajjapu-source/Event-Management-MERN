import Project from '../models/Project.js';
import { isMongoConnected } from '../config/db.js';
import { memoryStore } from '../data/memoryStore.js';

// @desc    Get all projects (with optional category filter)
// @route   GET /api/projects
// @access  Public
export const getProjects = async (req, res) => {
  try {
    const { category, featured } = req.query;

    if (isMongoConnected) {
      let query = {};
      if (category && category !== 'All') {
        query.category = category;
      }
      if (featured !== undefined) {
        query.featured = featured === 'true';
      }

      const projects = await Project.find(query).sort({ order: 1, createdAt: -1 });
      return res.json({
        success: true,
        count: projects.length,
        source: 'mongodb',
        data: projects
      });
    } else {
      const projects = memoryStore.getProjects({
        category,
        featured: featured !== undefined ? featured === 'true' : undefined
      });
      return res.json({
        success: true,
        count: projects.length,
        source: 'memory',
        data: projects
      });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get single project by ID
// @route   GET /api/projects/:id
// @access  Public
export const getProjectById = async (req, res) => {
  try {
    const { id } = req.params;

    if (isMongoConnected) {
      const project = await Project.findById(id);
      if (!project) {
        return res.status(404).json({ success: false, message: 'Project not found' });
      }
      return res.json({ success: true, data: project });
    } else {
      const project = memoryStore.getProjectById(id);
      if (!project) {
        return res.status(404).json({ success: false, message: 'Project not found' });
      }
      return res.json({ success: true, data: project });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Create new project
// @route   POST /api/projects
// @access  Private (Admin)
export const createProject = async (req, res) => {
  try {
    const { title, description, category, image, tags, liveUrl, githubUrl, featured, highlights, order } = req.body;

    if (!title || !description) {
      return res.status(400).json({ success: false, message: 'Title and description are required' });
    }

    const projectPayload = {
      title,
      description,
      category: category || 'Full Stack',
      image: image || 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=800&q=80',
      tags: Array.isArray(tags) ? tags : (typeof tags === 'string' ? tags.split(',').map(t => t.trim()) : []),
      liveUrl: liveUrl || '',
      githubUrl: githubUrl || '',
      featured: Boolean(featured),
      highlights: Array.isArray(highlights) ? highlights : (typeof highlights === 'string' ? highlights.split('\n').map(h => h.trim()).filter(Boolean) : []),
      order: Number(order) || 0
    };

    if (isMongoConnected) {
      const project = await Project.create(projectPayload);
      return res.status(201).json({ success: true, data: project });
    } else {
      const project = memoryStore.createProject(projectPayload);
      return res.status(201).json({ success: true, data: project });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Update project
// @route   PUT /api/projects/:id
// @access  Private (Admin)
export const updateProject = async (req, res) => {
  try {
    const { id } = req.params;

    let payload = { ...req.body };
    if (payload.tags && typeof payload.tags === 'string') {
      payload.tags = payload.tags.split(',').map(t => t.trim());
    }
    if (payload.highlights && typeof payload.highlights === 'string') {
      payload.highlights = payload.highlights.split('\n').map(h => h.trim()).filter(Boolean);
    }

    if (isMongoConnected) {
      const updated = await Project.findByIdAndUpdate(id, payload, { new: true, runValidators: true });
      if (!updated) {
        return res.status(404).json({ success: false, message: 'Project not found' });
      }
      return res.json({ success: true, data: updated });
    } else {
      const updated = memoryStore.updateProject(id, payload);
      if (!updated) {
        return res.status(404).json({ success: false, message: 'Project not found' });
      }
      return res.json({ success: true, data: updated });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Delete project
// @route   DELETE /api/projects/:id
// @access  Private (Admin)
export const deleteProject = async (req, res) => {
  try {
    const { id } = req.params;

    if (isMongoConnected) {
      const project = await Project.findByIdAndDelete(id);
      if (!project) {
        return res.status(404).json({ success: false, message: 'Project not found' });
      }
      return res.json({ success: true, message: 'Project removed successfully' });
    } else {
      const deleted = memoryStore.deleteProject(id);
      if (!deleted) {
        return res.status(404).json({ success: false, message: 'Project not found' });
      }
      return res.json({ success: true, message: 'Project removed successfully' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

