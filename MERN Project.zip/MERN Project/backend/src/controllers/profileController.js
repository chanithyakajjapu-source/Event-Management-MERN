import { isMongoConnected } from '../config/db.js';
import { memoryStore } from '../data/memoryStore.js';
import Experience from '../models/Experience.js';
import Project from '../models/Project.js';
import Skill from '../models/Skill.js';
import { initialProfile, initialTestimonials } from '../data/initialData.js';

// @desc    Get complete portfolio profile data
// @route   GET /api/profile
// @access  Public
export const getProfile = async (req, res) => {
  try {
    if (isMongoConnected) {
      const experiences = await Experience.find().sort({ createdAt: -1 });
      const projectsCount = await Project.countDocuments();
      const skillsCount = await Skill.countDocuments();

      return res.json({
        success: true,
        data: {
          ...initialProfile,
          projectsCount,
          skillsCount,
          experiences: experiences.length ? experiences : memoryStore.experiences,
          testimonials: initialTestimonials
        }
      });
    } else {
      const profile = memoryStore.getProfile();
      return res.json({
        success: true,
        data: profile
      });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Update portfolio profile
// @route   PUT /api/profile
// @access  Private (Admin)
export const updateProfile = async (req, res) => {
  try {
    const updated = memoryStore.updateProfile(req.body);
    return res.json({
      success: true,
      data: updated
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

