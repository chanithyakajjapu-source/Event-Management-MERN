import http from 'http';
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import authRoutes from './routes/authRoutes.js';
import projectRoutes from './routes/projectRoutes.js';
import contactRoutes from './routes/contactRoutes.js';
import skillRoutes from './routes/skillRoutes.js';
import profileRoutes from './routes/profileRoutes.js';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => {
  res.json({ status: 'online', database: 'in-memory-fallback' });
});

app.use('/api/auth', authRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/contact', contactRoutes);
app.use('/api/skills', skillRoutes);
app.use('/api/profile', profileRoutes);

const server = app.listen(0, async () => {
  const port = server.address().port;
  console.log(`Test server running on port ${port}`);

  try {
    // 1. Health check
    const health = await fetch(`http://127.0.0.1:${port}/api/health`).then(r => r.json());
    console.log('✅ Health API:', JSON.stringify(health));

    // 2. Projects check
    const projects = await fetch(`http://127.0.0.1:${port}/api/projects`).then(r => r.json());
    console.log(`✅ Projects API: count=${projects.count}, source=${projects.source}`);

    // 3. Contact submission check
    const contactRes = await fetch(`http://127.0.0.1:${port}/api/contact`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Alex Tester',
        email: 'tester@example.com',
        subject: 'MERN Portfolio Test',
        message: 'Testing contact submission endpoint'
      })
    }).then(r => r.json());
    console.log('✅ Contact Submission:', contactRes.message);

    // 4. Admin Auth check
    const authRes = await fetch(`http://127.0.0.1:${port}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'admin@example.com',
        password: 'admin123'
      })
    }).then(r => r.json());
    console.log('✅ Admin Login:', authRes.success ? 'Success (JWT generated)' : 'Failed');

    console.log('\n🎉 ALL MERN BACKEND ENDPOINTS PASSED CLEANLY!\n');
  } catch (err) {
    console.error('❌ Test failed:', err);
  } finally {
    server.close();
    process.exit(0);
  }
});

