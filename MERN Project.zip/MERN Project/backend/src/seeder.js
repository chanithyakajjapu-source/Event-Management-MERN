import mongoose from 'mongoose';
import dotenv from 'dotenv';
import User from './models/User.js';
import Project from './models/Project.js';
import Skill from './models/Skill.js';
import Contact from './models/Contact.js';
import Experience from './models/Experience.js';
import { initialProjects, initialSkills, initialExperiences } from './data/initialData.js';

dotenv.config();

const importData = async () => {
  try {
    const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/portfolio_db';
    console.log(`⏳ Connecting to MongoDB at ${uri}...`);
    await mongoose.connect(uri);
    console.log(`✅ Connected to MongoDB.`);

    // Clear existing collections
    console.log(`🧹 Clearing existing collections...`);
    await User.deleteMany();
    await Project.deleteMany();
    await Skill.deleteMany();
    await Contact.deleteMany();
    await Experience.deleteMany();

    // Create Admin User
    const adminEmail = process.env.ADMIN_EMAIL || 'admin@example.com';
    const adminPassword = process.env.ADMIN_PASSWORD || 'admin123';

    await User.create({
      name: 'Portfolio Admin',
      email: adminEmail,
      password: adminPassword,
      role: 'admin'
    });
    console.log(`👤 Admin created (${adminEmail} / ${adminPassword})`);

    // Insert Projects
    await Project.insertMany(initialProjects);
    console.log(`📂 Inserted ${initialProjects.length} initial projects`);

    // Insert Skills
    await Skill.insertMany(initialSkills);
    console.log(`⚡ Inserted ${initialSkills.length} skills`);

    // Insert Experiences
    await Experience.insertMany(initialExperiences);
    console.log(`💼 Inserted ${initialExperiences.length} experiences`);

    // Insert sample contact inquiry
    await Contact.create({
      name: 'Sarah Connor',
      email: 'sarah@techfuture.io',
      subject: 'Tech Lead / Senior Full Stack Role',
      message: 'Hello Alex! We loved your portfolio projects and would like to arrange an introductory interview with our engineering team.',
      isRead: false
    });
    console.log(`📬 Inserted sample contact inquiry`);

    console.log(`\n🎉 Portfolio Data Seeded Successfully!\n`);
    process.exit();
  } catch (error) {
    console.error(`❌ Seeder Error: ${error.message}`);
    process.exit(1);
  }
};

const destroyData = async () => {
  try {
    const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/portfolio_db';
    await mongoose.connect(uri);

    await User.deleteMany();
    await Project.deleteMany();
    await Skill.deleteMany();
    await Contact.deleteMany();
    await Experience.deleteMany();

    console.log(`🗑️ All portfolio data destroyed.`);
    process.exit();
  } catch (error) {
    console.error(`❌ Error destroying data: ${error.message}`);
    process.exit(1);
  }
};

if (process.argv[2] === '-d') {
  destroyData();
} else {
  importData();
}

