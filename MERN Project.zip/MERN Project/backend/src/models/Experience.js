import mongoose from 'mongoose';

const experienceSchema = new mongoose.Schema(
  {
    role: {
      type: String,
      required: true,
      trim: true
    },
    company: {
      type: String,
      required: true,
      trim: true
    },
    period: {
      type: String,
      required: true
    },
    location: {
      type: String,
      default: 'Remote'
    },
    description: {
      type: String,
      required: true
    },
    technologies: {
      type: [String],
      default: []
    }
  },
  {
    timestamps: true
  }
);

const Experience = mongoose.model('Experience', experienceSchema);
export default Experience;

