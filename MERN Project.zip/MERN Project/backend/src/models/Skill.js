import mongoose from 'mongoose';

const skillSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Skill name is required'],
      trim: true
    },
    category: {
      type: String,
      required: [true, 'Category is required'],
      enum: ['Frontend', 'Backend', 'Database', 'DevOps & Tools', 'Other'],
      default: 'Frontend'
    },
    proficiency: {
      type: Number,
      min: 0,
      max: 100,
      default: 80
    },
    icon: {
      type: String,
      default: 'code'
    }
  },
  {
    timestamps: true
  }
);

const Skill = mongoose.model('Skill', skillSchema);
export default Skill;

