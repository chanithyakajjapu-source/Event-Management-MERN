import mongoose from 'mongoose';

export let isMongoConnected = false;

export const connectDB = async () => {
  const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/portfolio_db';
  
  try {
    const conn = await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 1500 // 1.5s quick timeout for instant dev startup if offline
    });
    isMongoConnected = true;
    console.log(`✅ [MongoDB Connected] Host: ${conn.connection.host}`);
    return true;
  } catch (error) {
    isMongoConnected = false;
    console.log(`⚠️  [MongoDB Offline] Could not connect to MongoDB at ${uri}`);
    console.log(`ℹ️  [Fallback Mode] The server is seamlessly running using the In-Memory Store.`);
    console.log(`ℹ️  To connect to real MongoDB: start your local MongoDB service or set MONGODB_URI in backend/.env to MongoDB Atlas.\n`);
    return false;
  }
};

