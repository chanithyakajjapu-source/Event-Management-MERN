@echo off
title MERN Personal Portfolio Launcher
echo ====================================================
echo  Launching Full Stack MERN Personal Portfolio
echo ====================================================
echo.
set "ComSpec=C:\Windows\System32\cmd.exe"
set "COMSPEC=C:\Windows\System32\cmd.exe"

echo Starting Backend API on http://localhost:5000 ...
start "MERN Portfolio - Backend (Port 5000)" cmd /k "cd backend && npm run dev"

echo Starting Frontend on http://localhost:5173 ...
start "MERN Portfolio - Frontend (Port 5173)" cmd /k "cd frontend && npm run dev"

timeout /t 3 >nul
start http://localhost:5173

echo.
echo ====================================================
echo  Servers are running!
echo  - Frontend Web App: http://localhost:5173
echo  - Backend REST API: http://localhost:5000
echo  - Admin Login: admin@example.com / admin123
echo ====================================================
pause

