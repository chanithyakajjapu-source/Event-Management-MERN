import React from 'react';
import { ArrowRight, Download, Github, Linkedin, Mail, Twitter, Terminal, Sparkles, CheckCircle2 } from 'lucide-react';

export default function Hero({ profile }) {
  const currentProfile = profile || {
    name: "Alex Morgan",
    title: "Full Stack MERN Developer",
    tagline: "Building high-performance web applications, scalable backends, and pixel-perfect interactive user interfaces.",
    github: "https://github.com",
    linkedin: "https://linkedin.com",
    twitter: "https://twitter.com",
    email: "alex.morgan.dev@example.com"
  };

  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-28 overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-indigo-600/15 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute top-1/3 right-10 w-[350px] h-[350px] bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Intro */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            {/* Status Pill */}
            <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-slate-800/80 border border-slate-700/70 text-xs font-medium text-slate-300 shadow-sm backdrop-blur-sm">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Available for full-time opportunities & projects</span>
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-white leading-tight">
              Hi, I'm <span className="text-gradient">{currentProfile.name}</span>
              <br />
              <span className="text-2xl sm:text-3xl md:text-4xl text-slate-300 font-semibold mt-2 block">
                {currentProfile.title}
              </span>
            </h1>

            {/* Description */}
            <p className="text-base sm:text-lg text-slate-400 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
              {currentProfile.tagline}
            </p>

            {/* Tech Pill highlights */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2 pt-1">
              {['MongoDB', 'Express.js', 'React 18', 'Node.js', 'Tailwind CSS', 'REST & GraphQL'].map((tech) => (
                <span
                  key={tech}
                  className="px-2.5 py-1 rounded-md text-xs font-mono bg-slate-800/90 text-indigo-300 border border-slate-700/60"
                >
                  {tech}
                </span>
              ))}
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-3">
              <a
                href="#projects"
                className="inline-flex items-center space-x-2 px-6 py-3.5 rounded-xl font-semibold text-sm text-white bg-indigo-600 hover:bg-indigo-500 shadow-lg shadow-indigo-600/30 hover:shadow-indigo-600/50 hover:-translate-y-0.5 transition-all"
              >
                <span>View Projects</span>
                <ArrowRight className="w-4 h-4" />
              </a>

              <a
                href="#contact"
                className="inline-flex items-center space-x-2 px-6 py-3.5 rounded-xl font-semibold text-sm text-slate-200 bg-slate-800/80 hover:bg-slate-700 border border-slate-700 hover:border-slate-600 hover:-translate-y-0.5 transition-all"
              >
                <Mail className="w-4 h-4 text-indigo-400" />
                <span>Get In Touch</span>
              </a>

              <a
                href="#about"
                className="inline-flex items-center space-x-2 px-4 py-3.5 rounded-xl text-sm font-medium text-slate-400 hover:text-white transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>Resume / Bio</span>
              </a>
            </div>

            {/* Social Links */}
            <div className="pt-4 flex items-center justify-center lg:justify-start space-x-4">
              <span className="text-xs font-mono uppercase tracking-wider text-slate-500">Connect:</span>
              <a
                href={currentProfile.github}
                target="_blank"
                rel="noreferrer"
                className="p-2.5 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-700/50 transition-colors"
                aria-label="GitHub Profile"
              >
                <Github className="w-4 h-4" />
              </a>
              <a
                href={currentProfile.linkedin}
                target="_blank"
                rel="noreferrer"
                className="p-2.5 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-700/50 transition-colors"
                aria-label="LinkedIn Profile"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <a
                href={currentProfile.twitter}
                target="_blank"
                rel="noreferrer"
                className="p-2.5 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-700/50 transition-colors"
                aria-label="Twitter Profile"
              >
                <Twitter className="w-4 h-4" />
              </a>
              <a
                href={`mailto:${currentProfile.email}`}
                className="p-2.5 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-700/50 transition-colors"
                aria-label="Email Me"
              >
                <Mail className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Right Column: Code Window Graphic */}
          <div className="lg:col-span-5">
            <div className="relative mx-auto max-w-lg lg:max-w-none">
              <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-indigo-500/30 to-cyan-500/20 blur-xl opacity-75" />
              <div className="relative rounded-2xl bg-[#0f172a] border border-slate-800 shadow-2xl overflow-hidden font-mono text-xs sm:text-sm">
                {/* Window header */}
                <div className="flex items-center justify-between px-4 py-3 bg-[#1e293b]/70 border-b border-slate-800">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-rose-500/80" />
                    <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                    <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                  </div>
                  <div className="flex items-center space-x-1.5 text-slate-400 text-xs">
                    <Terminal className="w-3.5 h-3.5 text-indigo-400" />
                    <span>developer.config.ts</span>
                  </div>
                  <div className="w-12 text-right text-[10px] text-slate-500">MERN</div>
                </div>

                {/* Code body */}
                <div className="p-5 text-slate-300 space-y-2 leading-relaxed select-none">
                  <div className="text-slate-500">// Personal developer blueprint</div>
                  <div>
                    <span className="text-indigo-400">const</span>{' '}
                    <span className="text-yellow-300">developer</span> = {'{'}
                  </div>
                  <div className="pl-4">
                    <span className="text-slate-400">name:</span>{' '}
                    <span className="text-emerald-400">'{currentProfile.name}'</span>,
                  </div>
                  <div className="pl-4">
                    <span className="text-slate-400">role:</span>{' '}
                    <span className="text-emerald-400">'Full Stack Engineer'</span>,
                  </div>
                  <div className="pl-4">
                    <span className="text-slate-400">coreStack:</span> [
                    <span className="text-cyan-300">'MongoDB'</span>,{' '}
                    <span className="text-cyan-300">'Express'</span>,{' '}
                    <span className="text-cyan-300">'React'</span>,{' '}
                    <span className="text-cyan-300">'Node'</span>],
                  </div>
                  <div className="pl-4">
                    <span className="text-slate-400">focus:</span> [
                    <span className="text-purple-300">'Scalable APIs'</span>,{' '}
                    <span className="text-purple-300">'High UX'</span>],
                  </div>
                  <div className="pl-4">
                    <span className="text-slate-400">status:</span>{' '}
                    <span className="text-emerald-400">'Ready for hiring'</span>,
                  </div>
                  <div className="pl-4">
                    <span className="text-slate-400">hireable:</span>{' '}
                    <span className="text-indigo-400">true</span>
                  </div>
                  <div>{'};'}</div>
                  <div className="pt-2 text-slate-500">// Let's build something remarkable together!</div>
                  <div>
                    <span className="text-indigo-400">export default</span>{' '}
                    <span className="text-yellow-300">developer</span>;
                  </div>
                </div>

                {/* Window footer */}
                <div className="px-4 py-2 bg-[#090d16] border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <div className="flex items-center space-x-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Clean Architecture Certified</span>
                  </div>
                  <span className="text-indigo-400">TypeScript 5.4</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

