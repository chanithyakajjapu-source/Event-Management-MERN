import React from 'react';
import { Layers, Zap, ShieldCheck, Smartphone, Award, Briefcase, Users, Star } from 'lucide-react';

export default function About({ profile }) {
  const currentProfile = profile || {
    bio: "Hello! I am a passionate Full Stack Software Engineer specializing in the MERN stack (MongoDB, Express, React, Node.js). I love designing elegant architectures, crafting intuitive UI/UX, and engineering reliable REST APIs.",
    location: "San Francisco, CA / Remote",
    email: "alex.morgan.dev@example.com",
    stats: [
      { label: "Years Experience", value: "3+" },
      { label: "Completed Projects", value: "24+" },
      { label: "Open Source Stars", value: "1.2k" },
      { label: "Client Satisfaction", value: "100%" }
    ]
  };

  const pillars = [
    {
      icon: <Layers className="w-6 h-6 text-indigo-400" />,
      title: "Clean MERN Architecture",
      desc: "Modular MVC backends, scalable REST/GraphQL APIs, and well-structured React hooks & components."
    },
    {
      icon: <Zap className="w-6 h-6 text-amber-400" />,
      title: "Optimized Performance",
      desc: "Fast bundle execution with Vite, optimized MongoDB indexing, lazy loading, and intelligent caching."
    },
    {
      icon: <ShieldCheck className="w-6 h-6 text-emerald-400" />,
      title: "Security by Design",
      desc: "JWT authentication, sanitized database inputs, robust CORS rules, and protected API routes."
    },
    {
      icon: <Smartphone className="w-6 h-6 text-cyan-400" />,
      title: "Responsive & Accessible",
      desc: "Fluid, mobile-first design system built with Tailwind CSS conforming to modern accessibility standards."
    }
  ];

  return (
    <section id="about" className="py-20 md:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
          <span className="text-xs font-mono uppercase tracking-widest text-indigo-400 font-semibold">
            About The Engineer
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Crafting Digital Experiences with Passion & Precision
          </h2>
          <p className="text-slate-400 text-base leading-relaxed">
            A developer who cares about both the pixel-level details of the frontend and the data reliability of the database.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 mb-16">
          {(currentProfile.stats || []).map((stat, idx) => (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800/80 text-center hover:border-indigo-500/40 transition-all hover:-translate-y-1 group"
            >
              <div className="text-3xl sm:text-4xl font-black text-indigo-400 group-hover:text-indigo-300 transition-colors">
                {stat.value}
              </div>
              <div className="text-xs sm:text-sm font-medium text-slate-400 mt-1">
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Narrative & Pillars */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Bio text */}
          <div className="lg:col-span-5 space-y-5">
            <h3 className="text-2xl font-bold text-white">
              Bridging Ideas into Production-Ready Code
            </h3>
            <p className="text-slate-300 leading-relaxed text-sm sm:text-base">
              {currentProfile.bio}
            </p>
            <p className="text-slate-400 leading-relaxed text-sm">
              My engineering philosophy is rooted in pragmatism: choosing the right tool for the job, writing maintainable code that future teammates love to touch, and delivering rapid value to users.
            </p>

            <div className="pt-2 flex flex-col sm:flex-row gap-4 text-xs font-mono text-slate-400">
              <div className="flex items-center space-x-2">
                <span className="text-indigo-400">📍</span>
                <span>{currentProfile.location}</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-indigo-400">✉️</span>
                <span>{currentProfile.email}</span>
              </div>
            </div>
          </div>

          {/* Pillars Cards */}
          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {pillars.map((pillar, i) => (
              <div
                key={i}
                className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 hover:border-slate-700 transition-all group"
              >
                <div className="w-12 h-12 rounded-xl bg-slate-800/80 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  {pillar.icon}
                </div>
                <h4 className="text-base font-semibold text-white mb-2">{pillar.title}</h4>
                <p className="text-xs text-slate-400 leading-relaxed">{pillar.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

