import React from 'react';
import { Quote, Star } from 'lucide-react';

export default function Testimonials({ testimonials }) {
  const currentTestimonials = testimonials || [];

  if (currentTestimonials.length === 0) return null;

  return (
    <section className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-14">
          <span className="text-xs font-mono uppercase tracking-widest text-indigo-400 font-semibold">
            Endorsements
          </span>
          <h2 className="text-3xl font-extrabold text-white tracking-tight">
            What Engineering Leaders Say
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {currentTestimonials.map((item, index) => (
            <div
              key={index}
              className="p-7 rounded-2xl bg-slate-900/80 border border-slate-800/80 hover:border-slate-700 transition-all flex flex-col justify-between relative group shadow-lg shadow-black/20"
            >
              <div className="space-y-4">
                <Quote className="w-8 h-8 text-indigo-500/30 group-hover:text-indigo-500/60 transition-colors" />
                <p className="text-slate-300 text-sm sm:text-base italic leading-relaxed">
                  "{item.quote}"
                </p>
              </div>

              <div className="flex items-center space-x-3.5 pt-6 mt-6 border-t border-slate-800">
                <img
                  src={item.avatar}
                  alt={item.name}
                  className="w-11 h-11 rounded-full object-cover border border-slate-700"
                />
                <div>
                  <h4 className="text-sm font-bold text-white">{item.name}</h4>
                  <p className="text-xs text-slate-400">{item.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

