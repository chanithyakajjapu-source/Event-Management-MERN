import React, { useState, useEffect } from 'react';
import { X, Layers, Mail, Plus, Trash2, Edit3, LogOut, CheckCircle2, RefreshCw } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { fetchContactMessages, markMessageRead, deleteMessage, deleteProject } from '../../services/api';
import MessagesList from './MessagesList';
import ProjectEditor from './ProjectEditor';

export default function AdminDashboard({ projects, onClose, onRefreshData }) {
  const [activeTab, setActiveTab] = useState('messages');
  const [messages, setMessages] = useState([]);
  const [editingProject, setEditingProject] = useState(null);
  const [isCreatingProject, setIsCreatingProject] = useState(false);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const { user, logout } = useAuth();

  const loadMessages = async () => {
    setLoadingMessages(true);
    try {
      const res = await fetchContactMessages();
      if (res.data?.success) {
        setMessages(res.data.data);
      }
    } catch (err) {
      console.error('Failed to load messages', err);
    } finally {
      setLoadingMessages(false);
    }
  };

  useEffect(() => {
    loadMessages();
  }, []);

  const handleMarkRead = async (id) => {
    try {
      await markMessageRead(id);
      setMessages((prev) =>
        prev.map((m) => (m._id === id ? { ...m, isRead: true } : m))
      );
    } catch (err) {
      console.error('Error marking message read', err);
    }
  };

  const handleDeleteMessage = async (id) => {
    if (!window.confirm('Delete this message permanently?')) return;
    try {
      await deleteMessage(id);
      setMessages((prev) => prev.filter((m) => m._id !== id));
    } catch (err) {
      console.error('Error deleting message', err);
    }
  };

  const handleDeleteProject = async (id) => {
    if (!window.confirm('Delete this project permanently from your portfolio?')) return;
    try {
      await deleteProject(id);
      onRefreshData && onRefreshData();
    } catch (err) {
      console.error('Error deleting project', err);
    }
  };

  const handleProjectSaved = () => {
    setEditingProject(null);
    setIsCreatingProject(false);
    onRefreshData && onRefreshData();
  };

  const unreadCount = messages.filter((m) => !m.isRead).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-4xl max-h-[90vh] overflow-hidden bg-[#0f172a] border border-slate-700 rounded-2xl shadow-2xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 bg-[#111c33] border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs border border-emerald-500/30">
              CMS
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Portfolio Admin Portal</h3>
              <p className="text-[11px] text-slate-400 font-mono">Logged in as {user?.email}</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => {
                logout();
                onClose();
              }}
              className="p-2 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition-colors"
              title="Logout"
            >
              <LogOut className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
              title="Close CMS"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation & Stats */}
        <div className="px-6 py-3 bg-[#0c1424] border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => {
                setActiveTab('messages');
                setIsCreatingProject(false);
                setEditingProject(null);
              }}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'messages' && !isCreatingProject && !editingProject
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Mail className="w-3.5 h-3.5" />
              <span>Inquiries ({messages.length})</span>
              {unreadCount > 0 && (
                <span className="w-2 h-2 rounded-full bg-rose-400 animate-pulse" />
              )}
            </button>

            <button
              onClick={() => {
                setActiveTab('projects');
                setIsCreatingProject(false);
                setEditingProject(null);
              }}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'projects' && !isCreatingProject && !editingProject
                  ? 'bg-indigo-600 text-white shadow'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Manage Projects ({projects?.length || 0})</span>
            </button>
          </div>

          <div>
            {activeTab === 'projects' && !isCreatingProject && !editingProject && (
              <button
                onClick={() => setIsCreatingProject(true)}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Project</span>
              </button>
            )}
            {activeTab === 'messages' && (
              <button
                onClick={loadMessages}
                className="flex items-center space-x-1 text-xs text-slate-400 hover:text-white transition-colors"
                title="Refresh Messages"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loadingMessages ? 'animate-spin' : ''}`} />
                <span>Refresh</span>
              </button>
            )}
          </div>
        </div>

        {/* Content Area */}
        <div className="p-6 overflow-y-auto flex-1">
          {/* If creating or editing a project */}
          {isCreatingProject || editingProject ? (
            <ProjectEditor
              project={editingProject}
              onSave={handleProjectSaved}
              onCancel={() => {
                setIsCreatingProject(false);
                setEditingProject(null);
              }}
            />
          ) : activeTab === 'messages' ? (
            <MessagesList
              messages={messages}
              onMarkRead={handleMarkRead}
              onDelete={handleDeleteMessage}
            />
          ) : (
            /* Projects Management Tab */
            <div className="space-y-3">
              {(projects || []).map((proj) => (
                <div
                  key={proj._id}
                  className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between gap-4"
                >
                  <div className="flex items-center space-x-4 min-w-0">
                    <img
                      src={proj.image || "https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=200&q=80"}
                      alt={proj.title}
                      className="w-16 h-12 rounded-lg object-cover bg-slate-950 shrink-0 border border-slate-800"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center space-x-2">
                        <h4 className="text-sm font-bold text-white truncate">{proj.title}</h4>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-900/40 text-indigo-300 font-mono">
                          {proj.category}
                        </span>
                        {proj.featured && (
                          <span className="text-[10px] px-2 py-0.5 rounded bg-amber-900/40 text-amber-300 font-mono">
                            Featured
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 truncate mt-0.5 max-w-md">
                        {proj.description}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 shrink-0">
                    <button
                      onClick={() => setEditingProject(proj)}
                      className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
                      title="Edit project"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDeleteProject(proj._id)}
                      className="p-2 rounded-lg bg-slate-800 text-rose-400 hover:bg-rose-500/20 hover:text-rose-300 transition-colors"
                      title="Delete project"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

