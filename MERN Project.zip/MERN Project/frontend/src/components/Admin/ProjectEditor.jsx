import React, { useState, useEffect } from 'react';
import { Save, X, Plus, Trash2 } from 'lucide-react';
import { createProject, updateProject } from '../../services/api';

export default function ProjectEditor({ project, onSave, onCancel }) {
  const isEditing = Boolean(project?._id);

  const [formData, setFormData] = useState({
    title: '',
    category: 'Full Stack',
    description: '',
    image: '',
    tags: '',
    liveUrl: '',
    githubUrl: '',
    featured: false,
    highlights: '',
    order: 0
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (project) {
      setFormData({
        title: project.title || '',
        category: project.category || 'Full Stack',
        description: project.description || '',
        image: project.image || '',
        tags: Array.isArray(project.tags) ? project.tags.join(', ') : (project.tags || ''),
        liveUrl: project.liveUrl || '',
        githubUrl: project.githubUrl || '',
        featured: Boolean(project.featured),
        highlights: Array.isArray(project.highlights) ? project.highlights.join('\n') : (project.highlights || ''),
        order: project.order || 0
      });
    }
  }, [project]);

  const handleChange = (e) => {
    const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title.trim() || !formData.description.trim()) {
      setError('Title and description are required.');
      return;
    }

    setLoading(true);
    setError('');

    const payload = {
      ...formData,
      tags: formData.tags.split(',').map((t) => t.trim()).filter(Boolean),
      highlights: formData.highlights.split('\n').map((h) => h.trim()).filter(Boolean)
    };

    try {
      let res;
      if (isEditing) {
        res = await updateProject(project._id, payload);
      } else {
        res = await createProject(payload);
      }

      if (res.data?.success) {
        onSave && onSave(res.data.data);
      } else {
        setError(res.data?.message || 'Operation failed');
      }
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Error saving project');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 text-slate-200">
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <h4 className="text-lg font-bold text-white">
          {isEditing ? 'Edit Project' : 'Add New Portfolio Project'}
        </h4>
        <button
          type="button"
          onClick={onCancel}
          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {error && (
        <div className="p-3 rounded-xl bg-rose-950/40 text-rose-300 border border-rose-800 text-xs">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="text-xs font-mono text-slate-300 block mb-1">Project Title *</label>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            required
            placeholder="e.g. AI Workflow Platform"
            className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div>
          <label className="text-xs font-mono text-slate-300 block mb-1">Category *</label>
          <select
            name="category"
            value={formData.category}
            onChange={handleChange}
            className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-indigo-500"
          >
            <option value="Full Stack">Full Stack</option>
            <option value="Frontend">Frontend</option>
            <option value="Backend">Backend</option>
            <option value="Mobile">Mobile</option>
            <option value="Other">Other</option>
          </select>
        </div>
      </div>

      <div>
        <label className="text-xs font-mono text-slate-300 block mb-1">Short Description *</label>
        <textarea
          rows={2}
          name="description"
          value={formData.description}
          onChange={handleChange}
          required
          placeholder="Brief explanation of what the project does..."
          className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-indigo-500 resize-none"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="text-xs font-mono text-slate-300 block mb-1">Live URL</label>
          <input
            type="url"
            name="liveUrl"
            value={formData.liveUrl}
            onChange={handleChange}
            placeholder="https://..."
            className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div>
          <label className="text-xs font-mono text-slate-300 block mb-1">GitHub Repo URL</label>
          <input
            type="url"
            name="githubUrl"
            value={formData.githubUrl}
            onChange={handleChange}
            placeholder="https://github.com/..."
            className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      <div>
        <label className="text-xs font-mono text-slate-300 block mb-1">Image URL (Unsplash or direct URL)</label>
        <input
          type="text"
          name="image"
          value={formData.image}
          onChange={handleChange}
          placeholder="https://images.unsplash.com/..."
          className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-indigo-500"
        />
      </div>

      <div>
        <label className="text-xs font-mono text-slate-300 block mb-1">Tags (Comma-separated)</label>
        <input
          type="text"
          name="tags"
          value={formData.tags}
          onChange={handleChange}
          placeholder="React, Node.js, Express, MongoDB, Tailwind"
          className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-indigo-500"
        />
      </div>

      <div>
        <label className="text-xs font-mono text-slate-300 block mb-1">Highlights (One per line)</label>
        <textarea
          rows={3}
          name="highlights"
          value={formData.highlights}
          onChange={handleChange}
          placeholder="Real-time WebSocket notifications&#10;Stripe payment gateway integrated&#10;99.9% test coverage"
          className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-indigo-500"
        />
      </div>

      <div className="flex items-center space-x-2 pt-1">
        <input
          type="checkbox"
          id="featuredCheckbox"
          name="featured"
          checked={formData.featured}
          onChange={handleChange}
          className="rounded bg-slate-800 border-slate-700 text-indigo-600 focus:ring-0"
        />
        <label htmlFor="featuredCheckbox" className="text-xs text-slate-300 select-none">
          Mark as Featured Project on homepage
        </label>
      </div>

      <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 rounded-xl border border-slate-700 text-xs text-slate-300 hover:bg-slate-800"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={loading}
          className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white shadow-md shadow-indigo-600/30 flex items-center space-x-1.5"
        >
          <Save className="w-4 h-4" />
          <span>{loading ? 'Saving...' : isEditing ? 'Update Project' : 'Create Project'}</span>
        </button>
      </div>
    </form>
  );
}

