import React from 'react';
import { Mail, Check, Trash2, Clock, CheckCheck, Reply } from 'lucide-react';

export default function MessagesList({ messages, onMarkRead, onDelete }) {
  if (!messages || messages.length === 0) {
    return (
      <div className="py-12 text-center text-slate-400">
        <Mail className="w-10 h-10 mx-auto mb-3 text-slate-600" />
        <p className="text-sm font-medium">No contact messages received yet.</p>
        <p className="text-xs text-slate-500 mt-1">Inquiries submitted through your portfolio contact form will show up here.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {messages.map((msg) => (
        <div
          key={msg._id}
          className={`p-4 rounded-xl border transition-all ${
            msg.isRead
              ? 'bg-slate-900/40 border-slate-800 text-slate-300'
              : 'bg-slate-800/80 border-indigo-500/40 text-white shadow-md shadow-indigo-950/20'
          }`}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
            <div className="flex items-center space-x-2">
              <span className="font-bold text-sm">{msg.name}</span>
              <span className="text-xs text-slate-400 font-mono">({msg.email})</span>
              {!msg.isRead && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  New
                </span>
              )}
            </div>

            <div className="flex items-center space-x-2 text-xs font-mono text-slate-400">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              <span>
                {new Date(msg.createdAt).toLocaleDateString()} {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>

          <div className="text-xs font-semibold text-indigo-300 mb-1">
            Subject: {msg.subject || 'Portfolio Inquiry'}
          </div>

          <p className="text-xs sm:text-sm text-slate-300 whitespace-pre-wrap leading-relaxed mb-3">
            {msg.message}
          </p>

          <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-800/80 text-xs">
            <a
              href={`mailto:${msg.email}?subject=Re: ${encodeURIComponent(msg.subject || 'Portfolio Inquiry')}`}
              className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-indigo-600/20 text-indigo-300 hover:bg-indigo-600/30 transition-colors"
            >
              <Reply className="w-3.5 h-3.5" />
              <span>Reply</span>
            </a>

            {!msg.isRead && (
              <button
                onClick={() => onMarkRead(msg._id)}
                className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Mark Read</span>
              </button>
            )}

            <button
              onClick={() => onDelete(msg._id)}
              className="flex items-center space-x-1 px-2.5 py-1.5 rounded-lg text-rose-400 hover:bg-rose-500/10 hover:text-rose-300 transition-colors"
              title="Delete message"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

