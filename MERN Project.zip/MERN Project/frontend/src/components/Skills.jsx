import React, { useState } from 'react';
import { Layout, Server, Database, Wrench, CheckCircle } from 'lucide-react';

export default function Skills({ skills }) {
  const [activeCategory, setActiveCategory] = useState('All');

  const categories = ['All', 'Frontend', 'Backend', 'Database', 'DevOps & Tools'];

  const filteredSkills = activeCategory === 'All'
    ? (skills || [])
    : (skills || []).filter(s => s.category.toLowerCase() === activeCategory.toLowerCase());

  const getCategoryIcon = (cat) => {
    switch (cat.toLowerCase()) {
      case 'frontend':
        return <Layout className="w-4 h-4 text-cyan-400" />;
      case 'backend':
        return <Server className="w-4 h-4 text-indigo-400" />;
      case 'database':
        return <Database className="w-4 h-4 text-emerald-400" />;
      default:
        return <Wrench className="w-4 h-4 text-amber-400" />;
    }
  };

  return (
    <section id="skills" className="py-20 md:py-28 relative bg-[#090d16]/70 border-y border-slate-800/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <span className="text-xs font-mono uppercase tracking-widest text-indigo-400 font-semibold">
            Technical Arsenal
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Skills & Modern Technologies
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            Technologies I leverage daily to architect and deploy high-performance applications.
          </p>

          {/* Filter Tabs */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-6">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-xl text-xs font-medium transition-all ${
                  activeCategory === cat
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                    : 'bg-slate-800/60 text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredSkills.map((skill, index) => (
            <div
              key={skill._id || index}
              className="p-4 rounded-xl bg-slate-900/80 border border-slate-800/80 hover:border-slate-700 transition-all hover:bg-slate-900 group"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2.5">
                  <div className="p-1.5 rounded-lg bg-slate-800/90 border border-slate-700/60">
                    {getCategoryIcon(skill.category)}
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-white group-hover:text-indigo-300 transition-colors">
                      {skill.name}
                    </h3>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {skill.category}
                    </span>
                  </div>
                </div>
                <span className="text-xs font-mono font-semibold text-indigo-400">
                  {skill.proficiency}%
                </span>
              </div>

              {/* Progress Bar */}
              <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-indigo-500 to-cyan-400 rounded-full transition-all duration-1000 ease-out"
                  style={{ width: `${skill.proficiency}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Key Competencies Strip */}
        <div className="mt-14 p-6 rounded-2xl bg-gradient-to-r from-indigo-950/40 via-slate-900/60 to-indigo-950/40 border border-indigo-900/30 flex flex-wrap items-center justify-around gap-6 text-center">
          <div className="space-y-1">
            <span className="text-xl font-bold text-white">Full-Stack MERN</span>
            <p className="text-xs text-slate-400">End-to-end architecture</p>
          </div>
          <div className="h-8 w-px bg-slate-800 hidden md:block" />
          <div className="space-y-1">
            <span className="text-xl font-bold text-white">RESTful & Microservices</span>
            <p className="text-xs text-slate-400">Stateless, decoupled APIs</p>
          </div>
          <div className="h-8 w-px bg-slate-800 hidden md:block" />
          <div className="space-y-1">
            <span className="text-xl font-bold text-white">CI/CD & Cloud Deploy</span>
            <p className="text-xs text-slate-400">Automated builds & tests</p>
          </div>
        </div>
      </div>
    </section>
  );
}

