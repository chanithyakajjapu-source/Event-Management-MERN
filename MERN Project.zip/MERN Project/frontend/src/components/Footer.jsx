import React from 'react';
import { ArrowUp, Heart, Code2, Github, Linkedin, Twitter, Mail } from 'lucide-react';

export default function Footer({ profile }) {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const currentProfile = profile || {
    name: 'Alex Morgan',
    github: 'https://github.com',
    linkedin: 'https://linkedin.com',
    twitter: 'https://twitter.com',
    email: 'alex.morgan.dev@example.com'
  };

  return (
    <footer className="bg-[#070a12] border-t border-slate-800/80 py-12 relative text-slate-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
        {/* Brand */}
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-600/30 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
            <Code2 className="w-4 h-4" />
          </div>
          <div>
            <span className="text-white font-bold text-sm tracking-tight">{currentProfile.name}</span>
            <span className="block text-[10px] font-mono text-slate-500">MERN Stack Architecture</span>
          </div>
        </div>

        {/* Center credits */}
        <div className="flex items-center space-x-1.5 text-center text-slate-400">
          <span>Engineered with MongoDB, Express, React & Node.js</span>
        </div>

        {/* Socials & Top Button */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3">
            <a
              href={currentProfile.github}
              target="_blank"
              rel="noreferrer"
              className="text-slate-400 hover:text-white transition-colors"
              aria-label="GitHub"
            >
              <Github className="w-4 h-4" />
            </a>
            <a
              href={currentProfile.linkedin}
              target="_blank"
              rel="noreferrer"
              className="text-slate-400 hover:text-white transition-colors"
              aria-label="LinkedIn"
            >
              <Linkedin className="w-4 h-4" />
            </a>
            <a
              href={currentProfile.twitter}
              target="_blank"
              rel="noreferrer"
              className="text-slate-400 hover:text-white transition-colors"
              aria-label="Twitter"
            >
              <Twitter className="w-4 h-4" />
            </a>
          </div>

          <button
            onClick={scrollToTop}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors"
            title="Back to Top"
            aria-label="Scroll back to top"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>
      </div>
    </footer>
  );
}

