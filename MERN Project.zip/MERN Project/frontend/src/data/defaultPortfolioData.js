export const defaultProfile = {
  name: "Alex Morgan",
  title: "Full Stack MERN Developer",
  tagline: "Engineering robust full-stack applications with MongoDB, Express, React, and Node.js.",
  bio: "I am a Full Stack Engineer dedicated to designing and building responsive, accessible, and high-performance digital products. With deep hands-on expertise across the entire MERN stack, I bridge the gap between complex backend architectures and sleek, user-centric interfaces.",
  location: "San Francisco, CA / Remote",
  email: "alex.morgan.dev@example.com",
  phone: "+1 (555) 019-2834",
  github: "https://github.com",
  linkedin: "https://linkedin.com",
  twitter: "https://twitter.com",
  resumeUrl: "#contact",
  stats: [
    { label: "Years Experience", value: "3+" },
    { label: "Projects Completed", value: "24+" },
    { label: "Code Commits", value: "1,500+" },
    { label: "Client Satisfaction", value: "100%" }
  ]
};

export const defaultProjects = [
  {
    _id: "p1",
    title: "DevFlow - Agile Collaboration Platform",
    description: "A real-time project management and team collaboration dashboard featuring kanban boards, live chat, role-based access control, and automated activity logs.",
    category: "Full Stack",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80",
    tags: ["React", "Node.js", "Express", "MongoDB", "Socket.io", "Tailwind CSS"],
    liveUrl: "https://example.com/devflow",
    githubUrl: "https://github.com/example/devflow",
    featured: true,
    highlights: [
      "Real-time websocket events for instant collaboration",
      "JWT authentication with refresh tokens",
      "MongoDB aggregation pipelines for team analytics"
    ]
  },
  {
    _id: "p2",
    title: "EcoMart - E-Commerce Platform",
    description: "Full-featured online store with product filtering, cart state management, Stripe payment processing, customer reviews, and order tracking.",
    category: "Full Stack",
    image: "https://images.unsplash.com/photo-1472851294608-062f824d29cc?auto=format&fit=crop&w=800&q=80",
    tags: ["React", "Redux", "Express", "MongoDB", "Stripe API", "Tailwind CSS"],
    liveUrl: "https://example.com/ecomart",
    githubUrl: "https://github.com/example/ecomart",
    featured: true,
    highlights: [
      "Seamless Stripe Checkout integration",
      "Admin portal for product and inventory management",
      "Optimized image uploads with Cloudinary"
    ]
  },
  {
    _id: "p3",
    title: "PulseAI - Content Intelligence Suite",
    description: "AI-assisted writing assistant with prompt history, custom tone analyzers, markdown export, and token usage dashboards powered by LLM APIs.",
    category: "Frontend",
    image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80",
    tags: ["React", "Vite", "Tailwind CSS", "REST API", "Framer Motion"],
    liveUrl: "https://example.com/pulseai",
    githubUrl: "https://github.com/example/pulseai",
    featured: true,
    highlights: [
      "Ultra-responsive dark mode UI with glassmorphism",
      "Streaming API response rendering",
      "Local storage sync for drafts"
    ]
  },
  {
    _id: "p4",
    title: "CloudVault - Secure API Gateway & Storage",
    description: "Microservice-ready RESTful API backend handling encrypted file storage, rate limiting, audit logs, and OAuth2 social authentication.",
    category: "Backend",
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80",
    tags: ["Node.js", "Express", "MongoDB", "JWT", "Redis", "Docker"],
    liveUrl: "https://example.com/cloudvault-api",
    githubUrl: "https://github.com/example/cloudvault-api",
    featured: false,
    highlights: [
      "Standardized error handling and request sanitization",
      "Rate limiting with Redis token bucket",
      "Comprehensive Postman test collection"
    ]
  },
  {
    _id: "p5",
    title: "CryptoScope - Realtime Market Tracker",
    description: "Interactive cryptocurrency analytics app displaying live price charts, order books, historical performance graphs, and personalized watchlist alerts.",
    category: "Frontend",
    image: "https://images.unsplash.com/photo-1621416894569-0f39ed31d247?auto=format&fit=crop&w=800&q=80",
    tags: ["React", "Chart.js", "Tailwind CSS", "CoinGecko API"],
    liveUrl: "https://example.com/cryptoscope",
    githubUrl: "https://github.com/example/cryptoscope",
    featured: false,
    highlights: [
      "Dynamic interactive charting with time-range toggles",
      "Clean currency conversion calculations",
      "Mobile-first responsive design"
    ]
  },
  {
    _id: "p6",
    title: "TaskPilot - Asynchronous Job Runner",
    description: "Developer utility to orchestrate asynchronous background tasks, monitor webhook deliveries, and retry failed HTTP requests automatically.",
    category: "Backend",
    image: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80",
    tags: ["Node.js", "Express", "MongoDB", "Worker Threads"],
    liveUrl: "https://example.com/taskpilot",
    githubUrl: "https://github.com/example/taskpilot",
    featured: false,
    highlights: [
      "Exponential backoff retry policy",
      "Webhook signature validation (HMAC SHA-256)",
      "Lightweight embedded web dashboard"
    ]
  }
];

export const defaultSkills = [
  { name: "React.js", category: "Frontend", proficiency: 95 },
  { name: "JavaScript (ES6+)", category: "Frontend", proficiency: 95 },
  { name: "TypeScript", category: "Frontend", proficiency: 85 },
  { name: "Tailwind CSS", category: "Frontend", proficiency: 92 },
  { name: "HTML5 / CSS3", category: "Frontend", proficiency: 95 },
  { name: "Redux Toolkit", category: "Frontend", proficiency: 85 },

  { name: "Node.js", category: "Backend", proficiency: 90 },
  { name: "Express.js", category: "Backend", proficiency: 92 },
  { name: "RESTful APIs", category: "Backend", proficiency: 95 },
  { name: "JWT & Authentication", category: "Backend", proficiency: 90 },
  { name: "Socket.io", category: "Backend", proficiency: 80 },

  { name: "MongoDB & Mongoose", category: "Database", proficiency: 92 },
  { name: "PostgreSQL", category: "Database", proficiency: 78 },
  { name: "Redis", category: "Database", proficiency: 80 },

  { name: "Git & GitHub", category: "DevOps & Tools", proficiency: 90 },
  { name: "Docker", category: "DevOps & Tools", proficiency: 78 },
  { name: "Postman", category: "DevOps & Tools", proficiency: 90 },
  { name: "Vercel / Cloud Hosting", category: "DevOps & Tools", proficiency: 85 }
];

export const defaultExperiences = [
  {
    role: "Senior Full Stack Engineer",
    company: "Apex Digital Solutions",
    period: "2023 - Present",
    location: "Remote",
    description: "Leading frontend and backend development for client-facing cloud applications. Architected resilient REST APIs with Express and MongoDB, reducing server latency by 35%. Mentored 4 junior engineers.",
    technologies: ["React", "Node.js", "Express", "MongoDB", "Tailwind CSS", "Docker"]
  },
  {
    role: "Full Stack Developer",
    company: "HyperScale Tech",
    period: "2021 - 2023",
    location: "San Francisco, CA",
    description: "Built modular web interfaces in React and robust backend microservices in Node.js. Integrated Stripe payment gateways, automated CI/CD deployment pipelines, and improved test coverage to 85%.",
    technologies: ["JavaScript", "React", "Node.js", "MongoDB", "Redux", "Jest"]
  },
  {
    role: "Frontend Developer Intern",
    company: "CodeCraft Studios",
    period: "2020 - 2021",
    location: "San Francisco, CA",
    description: "Developed responsive landing pages, interactive dashboards, and design system components. Partnered with UX designers to translate Figma mockups into reusable React components.",
    technologies: ["React", "HTML5", "CSS3", "JavaScript", "Git"]
  }
];

export const defaultTestimonials = [
  {
    quote: "Alex is an outstanding engineer who consistently delivers high-quality, maintainable code. His expertise in the MERN stack transformed our product delivery timeline.",
    name: "Sarah Jenkins",
    role: "VP of Engineering at CloudSphere",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80"
  },
  {
    quote: "Working with Alex was a fantastic experience. He has a rare combination of frontend polish and backend depth that makes complex features feel simple.",
    name: "David Chen",
    role: "Product Manager at Apex Labs",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80"
  }
];

