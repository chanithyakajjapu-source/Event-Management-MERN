import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Skills from './components/Skills';
import Projects from './components/Projects';
import Experience from './components/Experience';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import Footer from './components/Footer';
import AdminModal from './components/Admin/AdminModal';
import { fetchProfile, fetchProjects, fetchSkills } from './services/api';
import {
  defaultProfile,
  defaultProjects,
  defaultSkills,
  defaultExperiences,
  defaultTestimonials
} from './data/defaultPortfolioData';
import { Database, AlertTriangle } from 'lucide-react';

export default function App() {
  const [profile, setProfile] = useState(defaultProfile);
  const [projects, setProjects] = useState(defaultProjects);
  const [skills, setSkills] = useState(defaultSkills);
  const [experiences, setExperiences] = useState(defaultExperiences);
  const [testimonials, setTestimonials] = useState(defaultTestimonials);
  const [adminOpen, setAdminOpen] = useState(false);
  const [editingProject, setEditingProject] = useState(null);
  const [dataSource, setDataSource] = useState('loading'); // 'mongodb', 'memory', or 'local'

  const loadAllData = async () => {
    try {
      // 1. Fetch Projects
      try {
        const projRes = await fetchProjects();
        if (projRes.data?.success && projRes.data.data?.length > 0) {
          setProjects(projRes.data.data);
          setDataSource(projRes.data.source || 'connected');
        }
      } catch (e) {
        console.warn('Projects API unreachable, using default projects:', e.message);
      }

      // 2. Fetch Skills
      try {
        const skillRes = await fetchSkills();
        if (skillRes.data?.success && skillRes.data.data?.length > 0) {
          setSkills(skillRes.data.data);
        }
      } catch (e) {
        console.warn('Skills API unreachable, using default skills:', e.message);
      }

      // 3. Fetch Profile
      try {
        const profRes = await fetchProfile();
        if (profRes.data?.success && profRes.data.data) {
          setProfile(profRes.data.data);
          if (profRes.data.data.experiences?.length > 0) {
            setExperiences(profRes.data.data.experiences);
          }
          if (profRes.data.data.testimonials?.length > 0) {
            setTestimonials(profRes.data.data.testimonials);
          }
        }
      } catch (e) {
        console.warn('Profile API unreachable, using default profile:', e.message);
      }
    } catch (err) {
      console.error('Data loading error', err);
    }
  };

  useEffect(() => {
    loadAllData();
  }, []);

  const handleEditProject = (project) => {
    setEditingProject(project);
    setAdminOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#0a0f1d] text-slate-100 flex flex-col selection:bg-indigo-500 selection:text-white">
      {/* Top Navbar */}
      <Navbar onOpenAdmin={() => setAdminOpen(true)} />

      {/* Main Sections */}
      <main className="flex-1">
        <Hero profile={profile} />
        <About profile={profile} />
        <Skills skills={skills} />
        <Projects
          projects={projects}
          onOpenAdmin={() => setAdminOpen(true)}
          onEditProject={handleEditProject}
        />
        <Experience experiences={experiences} />
        <Testimonials testimonials={testimonials} />
        <Contact profile={profile} />
      </main>

      {/* Footer */}
      <Footer profile={profile} />

      {/* Admin CMS Modal */}
      <AdminModal
        isOpen={adminOpen}
        onClose={() => {
          setAdminOpen(false);
          setEditingProject(null);
        }}
        projects={projects}
        onRefreshData={loadAllData}
        editingProject={editingProject}
      />
    </div>
  );
}

