import axios from 'axios';

// Create Axios client with defaults
const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json'
  },
  timeout: 10000
});

// Request interceptor to attach JWT token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('portfolio_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor for unified handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Clear token if invalid
      localStorage.removeItem('portfolio_token');
      localStorage.removeItem('portfolio_user');
    }
    return Promise.reject(error);
  }
);

// Project Endpoints
export const fetchProjects = (category) => {
  const url = category && category !== 'All' ? `/projects?category=${encodeURIComponent(category)}` : '/projects';
  return api.get(url);
};

export const fetchProjectById = (id) => api.get(`/projects/${id}`);
export const createProject = (data) => api.post('/projects', data);
export const updateProject = (id, data) => api.put(`/projects/${id}`, data);
export const deleteProject = (id) => api.delete(`/projects/${id}`);

// Skills Endpoints
export const fetchSkills = (category) => {
  const url = category && category !== 'All' ? `/skills?category=${encodeURIComponent(category)}` : '/skills';
  return api.get(url);
};

// Profile Endpoints
export const fetchProfile = () => api.get('/profile');
export const updateProfile = (data) => api.put('/profile', data);

// Contact Endpoints
export const sendContactMessage = (data) => api.post('/contact', data);
export const fetchContactMessages = () => api.get('/contact');
export const markMessageRead = (id) => api.patch(`/contact/${id}/read`);
export const deleteMessage = (id) => api.delete(`/contact/${id}`);

// Auth Endpoints
export const loginAdmin = (credentials) => api.post('/auth/login', credentials);
export const fetchMe = () => api.get('/auth/me');

export default api;

