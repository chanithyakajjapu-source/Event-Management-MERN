$env:ComSpec = "C:\Windows\System32\cmd.exe"
$env:COMSPEC = "C:\Windows\System32\cmd.exe"

Write-Host "====================================================" -ForegroundColor Cyan
Write-Host "  Launching MERN Personal Portfolio Servers...     " -ForegroundColor Cyan
Write-Host "====================================================" -ForegroundColor Cyan

# Start Backend in new window
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd backend; node --watch src/server.js"

# Start Frontend in new window
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd frontend; npm run dev"

Start-Sleep -Seconds 2
Start-Process "http://localhost:5173"

Write-Host "Servers launched successfully!" -ForegroundColor Green
Write-Host "Frontend: http://localhost:5173" -ForegroundColor Yellow
Write-Host "Backend:  http://localhost:5000" -ForegroundColor Yellow
Write-Host "Admin Portal: admin@example.com / admin123" -ForegroundColor Magenta

